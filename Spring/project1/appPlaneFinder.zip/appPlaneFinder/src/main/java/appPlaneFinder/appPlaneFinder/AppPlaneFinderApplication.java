package appPlaneFinder.appPlaneFinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppPlaneFinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppPlaneFinderApplication.class, args);
	}

}
