package appPlaneFinder.appPlaneFinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppPlaneFinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
